import { Injectable } from '@angular/core';
import {HousingLocationInfo} from './housing-location';

@Injectable({
  providedIn: 'root'
})
export class HousingService {

  url = 'http://localhost:3000/locations';

  async getAllHousingLocations(): Promise<HousingLocationInfo[]> {
    const data = await fetch(this.url);
    return await data.json();
  }

  async getHousingLocationById(id: number): Promise<HousingLocationInfo> {
    const data = await fetch(`${this.url}/${id}`);
    return await data.json();
  }

  submitApplication(firstName: string, lastName: string, email: string) {
    console.log(firstName, lastName, email);
  }

  async getWeather(lat: number, lon: number): Promise<any> {
    const apiKey = '312a4a005b96419aa4f121837260801';
    const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${lat},${lon}&lang=es`;

    const response = await fetch(url);
    return await response.json();
  }
}
